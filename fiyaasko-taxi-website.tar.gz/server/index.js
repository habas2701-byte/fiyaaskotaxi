const express = require('express');
const cors = require('cors');
const { execSync } = require('child_process');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3001;

// Email configuration from environment variables
const SMTP_HOST = process.env.SMTP_HOST || '';
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '587');
const SMTP_USER = process.env.SMTP_USER || '';
const SMTP_PASS = process.env.SMTP_PASS || '';
const NOTIFICATION_EMAIL = process.env.NOTIFICATION_EMAIL || '';
const FROM_EMAIL = process.env.FROM_EMAIL || 'bookings@fiyaskotaxi.com';

/**
 * Create an email transporter if SMTP is configured.
 * Returns null if no config is set.
 */
function createTransporter() {
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS || !NOTIFICATION_EMAIL) {
    return null;
  }
  return nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: SMTP_PORT === 465,
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS,
    },
  });
}

/**
 * Send an email notification for a new booking.
 * Falls back to console.log if no SMTP is configured.
 */
async function sendBookingNotification(booking) {
  const subject = `🚕 New Booking - ${booking.name}`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #000; color: #fff; padding: 40px; border-radius: 16px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="font-size: 24px; margin: 0; font-weight: 300; letter-spacing: 2px;">FIYAASKO</h1>
        <p style="color: #888; font-size: 12px; letter-spacing: 3px; text-transform: uppercase;">Premium Taxi Service</p>
      </div>
      <div style="background: rgba(255,255,255,0.05); border-radius: 12px; padding: 24px; border: 1px solid rgba(255,255,255,0.1);">
        <h2 style="font-size: 18px; margin: 0 0 20px; color: #fff;">New Ride Booking Request</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Name</td><td style="padding: 8px 0; text-align: right; color: #fff;">${booking.name}</td></tr>
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid rgba(255,255,255,0.05);">Phone</td><td style="padding: 8px 0; text-align: right; color: #fff; border-top: 1px solid rgba(255,255,255,0.05);">${booking.phone}</td></tr>
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid rgba(255,255,255,0.05);">Pickup</td><td style="padding: 8px 0; text-align: right; color: #fff; border-top: 1px solid rgba(255,255,255,0.05);">${booking.pickup_location}</td></tr>
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid rgba(255,255,255,0.05);">Destination</td><td style="padding: 8px 0; text-align: right; color: #fff; border-top: 1px solid rgba(255,255,255,0.05);">${booking.destination}</td></tr>
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid rgba(255,255,255,0.05);">Date</td><td style="padding: 8px 0; text-align: right; color: #fff; border-top: 1px solid rgba(255,255,255,0.05);">${booking.booking_date}</td></tr>
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid rgba(255,255,255,0.05);">Time</td><td style="padding: 8px 0; text-align: right; color: #fff; border-top: 1px solid rgba(255,255,255,0.05);">${booking.booking_time}</td></tr>
          <tr><td style="padding: 8px 0; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid rgba(255,255,255,0.05);">Passengers</td><td style="padding: 8px 0; text-align: right; color: #fff; border-top: 1px solid rgba(255,255,255,0.05);">${booking.passengers}</td></tr>
        </table>
      </div>
      <p style="text-align: center; color: #555; font-size: 11px; margin-top: 30px;">
        Fiyaasko Taxi — Bergen op Zoom<br>
        Booking received at ${booking.created_at}
      </p>
    </div>
  `;

  const transporter = createTransporter();
  if (transporter) {
    try {
      await transporter.sendMail({
        from: FROM_EMAIL,
        to: NOTIFICATION_EMAIL,
        subject,
        html,
      });
      console.log(`📧 Email notification sent to ${NOTIFICATION_EMAIL}`);
    } catch (err) {
      console.error('❌ Failed to send email notification:', err.message);
      console.log('📋 Booking details logged as fallback:', JSON.stringify(booking, null, 2));
    }
  } else {
    console.log('📋 Email notification (SMTP not configured):');
    console.log(`  To: owner@fiyaskotaxi.com`);
    console.log(`  Subject: ${subject}`);
    console.log(`  Booking:`, JSON.stringify(booking, null, 2));
    console.log(`  💡 Set SMTP_HOST, SMTP_USER, SMTP_PASS, and NOTIFICATION_EMAIL env vars to enable email delivery.`);
  }
}

// Middleware
app.use(cors());
app.use(express.json());

/**
 * Validate booking input fields.
 * Returns an array of error messages (empty = valid).
 */
function validateBooking(body) {
  const errors = [];
  const { name, phone, pickup_location, destination, booking_date, booking_time, passengers } = body;

  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    errors.push('Name is required');
  }
  if (!phone || typeof phone !== 'string' || phone.trim().length === 0) {
    errors.push('Phone number is required');
  }
  if (!pickup_location || typeof pickup_location !== 'string' || pickup_location.trim().length === 0) {
    errors.push('Pickup location is required');
  }
  if (!destination || typeof destination !== 'string' || destination.trim().length === 0) {
    errors.push('Destination is required');
  }
  if (!booking_date || typeof booking_date !== 'string' || booking_date.trim().length === 0) {
    errors.push('Booking date is required');
  }
  if (!booking_time || typeof booking_time !== 'string' || booking_time.trim().length === 0) {
    errors.push('Booking time is required');
  }

  const pax = Number(passengers);
  if (passengers === undefined || passengers === null || !Number.isInteger(pax) || pax < 1) {
    errors.push('Passengers must be a positive integer');
  }

  return errors;
}

/**
 * Escape a value for use in a SQL string literal.
 * Doubles any single quotes to prevent SQL injection.
 */
function esc(val) {
  if (val === null || val === undefined) return 'NULL';
  return `'${String(val).replace(/'/g, "''")}'`;
}

/**
 * Execute a SQL statement via the team-db CLI.
 */
function dbExec(sql) {
  try {
    const output = execSync(`team-db ${JSON.stringify(sql)}`, {
      encoding: 'utf-8',
      timeout: 15000,
      maxBuffer: 1024 * 1024,
    });
    return { success: true, data: output.trim() };
  } catch (err) {
    return { success: false, error: err.stderr || err.message };
  }
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Fiyaasko Taxi Booking API' });
});

// POST /api/bookings — Create a new booking
app.post('/api/bookings', async (req, res) => {
  const validationErrors = validateBooking(req.body);
  if (validationErrors.length > 0) {
    return res.status(400).json({
      success: false,
      errors: validationErrors,
    });
  }

  const { name, phone, pickup_location, destination, booking_date, booking_time, passengers } = req.body;

  const sql = `INSERT INTO bookings (name, phone, pickup_location, destination, booking_date, booking_time, passengers) VALUES (${esc(name)}, ${esc(phone)}, ${esc(pickup_location)}, ${esc(destination)}, ${esc(booking_date)}, ${esc(booking_time)}, ${Number(passengers)})`;

  const result = dbExec(sql);

  if (!result.success) {
    console.error('Database error:', result.error);
    return res.status(500).json({
      success: false,
      error: 'Failed to save booking. Please try again.',
    });
  }

  // Send email notification (async, don't block response)
  const booking = { name, phone, pickup_location, destination, booking_date, booking_time, passengers };
  booking.created_at = new Date().toISOString().replace('T', ' ').split('.')[0];
  sendBookingNotification(booking).catch(err => {
    console.error('Email notification error:', err.message);
  });

  res.status(201).json({
    success: true,
    message: 'Booking created successfully!',
  });
});

// GET /api/bookings — List all bookings
app.get('/api/bookings', (req, res) => {
  const result = dbExec("SELECT * FROM bookings ORDER BY created_at DESC");

  if (!result.success) {
    console.error('Database error:', result.error);
    return res.status(500).json({
      success: false,
      error: 'Failed to fetch bookings.',
    });
  }

  try {
    const bookings = JSON.parse(result.data);
    res.json({ success: true, bookings });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: 'Failed to parse booking data.',
    });
  }
});

// GET /api/notifications/status — Check email config
app.get('/api/notifications/status', (req, res) => {
  const configured = !!(SMTP_HOST && SMTP_USER && SMTP_PASS && NOTIFICATION_EMAIL);
  res.json({
    success: true,
    email_configured: configured,
    notification_email: NOTIFICATION_EMAIL || 'not set (owner@fiyaskotaxi.com used as placeholder)',
    message: configured
      ? 'Email notifications are active. New bookings will be emailed to the owner.'
      : 'Email not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASS, and NOTIFICATION_EMAIL env vars to enable.',
  });
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚕 Fiyaasko Taxi Booking API running on http://0.0.0.0:${PORT}`);
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS || !NOTIFICATION_EMAIL) {
    console.log(`📧 Email notifications disabled. To enable, set:`);
    console.log(`   SMTP_HOST, SMTP_USER, SMTP_PASS, NOTIFICATION_EMAIL`);
  } else {
    console.log(`📧 Email notifications active → ${NOTIFICATION_EMAIL}`);
  }
});