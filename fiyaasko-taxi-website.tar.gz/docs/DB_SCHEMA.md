# Fiyaasko Taxi - Database Schema

## bookings Table

Created: May 28, 2026
Database: Shared team database (Turso/SQLite)

### Schema

| Column          | Type    | Constraints                        |
|-----------------|---------|------------------------------------|
| id              | INTEGER | PRIMARY KEY AUTOINCREMENT          |
| name            | TEXT    | NOT NULL                           |
| phone           | TEXT    | NOT NULL                           |
| pickup_location | TEXT    | NOT NULL                           |
| destination     | TEXT    | NOT NULL                           |
| booking_date    | TEXT    | NOT NULL                           |
| booking_time    | TEXT    | NOT NULL                           |
| passengers      | INTEGER | NOT NULL DEFAULT 1                 |
| created_at      | TEXT    | NOT NULL DEFAULT datetime('now')   |

### Usage

```sql
-- Insert a booking
INSERT INTO bookings (name, phone, pickup_location, destination, booking_date, booking_time, passengers)
VALUES ('John Doe', '+31 6 12345678', 'Bergen op Zoom Centrum', 'Schiphol Airport', '2026-06-01', '08:30', 2);

-- Query all bookings
SELECT * FROM bookings ORDER BY created_at DESC;

-- Query recent bookings
SELECT * FROM bookings WHERE booking_date >= date('now') ORDER BY booking_date, booking_time;
```