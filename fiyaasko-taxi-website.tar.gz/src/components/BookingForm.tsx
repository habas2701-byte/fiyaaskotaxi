import { useState, FormEvent } from 'react';
import { motion } from 'framer-motion';
import { Car, Calendar, Clock, Users, MapPin, Phone, User, CheckCircle, XCircle, Loader } from 'lucide-react';

// Use relative path so Vite proxy handles it in dev
const API_BASE = '';

interface FormData {
  name: string;
  phone: string;
  pickup_location: string;
  destination: string;
  booking_date: string;
  booking_time: string;
  passengers: number;
}

interface FormErrors {
  [key: string]: string;
}

const BookingForm = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    phone: '',
    pickup_location: '',
    destination: '',
    booking_date: '',
    booking_time: '',
    passengers: 1,
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [serverMessage, setServerMessage] = useState('');

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    if (!formData.pickup_location.trim()) newErrors.pickup_location = 'Pickup location is required';
    if (!formData.destination.trim()) newErrors.destination = 'Destination is required';
    if (!formData.booking_date) newErrors.booking_date = 'Date is required';
    if (!formData.booking_time) newErrors.booking_time = 'Time is required';
    if (formData.passengers < 1) newErrors.passengers = 'At least 1 passenger';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus('loading');
    setServerMessage('');

    try {
      const res = await fetch(`${API_BASE}/api/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setStatus('success');
        setServerMessage('Your ride has been booked! We\'ll contact you shortly.');
        setFormData({
          name: '',
          phone: '',
          pickup_location: '',
          destination: '',
          booking_date: '',
          booking_time: '',
          passengers: 1,
        });
      } else {
        setStatus('error');
        setServerMessage(
          data.errors ? data.errors.join(', ') : (data.error || 'Something went wrong. Please try again.')
        );
      }
    } catch (err) {
      setStatus('error');
      setServerMessage('Could not connect to the server. Please ensure the backend is running.');
    }
  };

  const updateField = (field: keyof FormData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => {
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    }
  };

  const inputClass = (field: string) =>
    `w-full bg-white/5 border ${errors[field] ? 'border-red-500/50' : 'border-white/10'} rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-white/30 transition-colors`;

  const labelClass = 'block text-white/60 text-xs uppercase tracking-widest mb-2';

  return (
    <section className="bg-black py-28 md:py-40 px-6 overflow-hidden relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.02)_0%,_transparent_60%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="flex justify-between items-end mb-16 md:mb-24"
        >
          <div>
            <h2 className="text-3xl md:text-5xl text-white tracking-tight">Book a Ride</h2>
            <p className="text-white/40 text-sm mt-3 max-w-md">
              Premium transportation in Bergen op Zoom. Enter your details and we'll take care of the rest.
            </p>
          </div>
          <span className="text-white/40 text-sm hidden md:block uppercase tracking-widest">Reserve now</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="liquid-glass rounded-3xl p-8 md:p-12 max-w-3xl mx-auto"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name & Phone */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className={labelClass}>
                  <User className="w-3 h-3 inline mr-1" /> Name
                </label>
                <input
                  type="text"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  className={inputClass('name')}
                />
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className={labelClass}>
                  <Phone className="w-3 h-3 inline mr-1" /> Phone
                </label>
                <input
                  type="tel"
                  placeholder="+31 6 12345678"
                  value={formData.phone}
                  onChange={(e) => updateField('phone', e.target.value)}
                  className={inputClass('phone')}
                />
                {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
              </div>
            </div>

            {/* Pickup & Destination */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className={labelClass}>
                  <MapPin className="w-3 h-3 inline mr-1" /> Pickup Location
                </label>
                <input
                  type="text"
                  placeholder="Address or landmark"
                  value={formData.pickup_location}
                  onChange={(e) => updateField('pickup_location', e.target.value)}
                  className={inputClass('pickup_location')}
                />
                {errors.pickup_location && <p className="text-red-400 text-xs mt-1">{errors.pickup_location}</p>}
              </div>
              <div>
                <label className={labelClass}>
                  <MapPin className="w-3 h-3 inline mr-1" /> Destination
                </label>
                <input
                  type="text"
                  placeholder="Where are you going?"
                  value={formData.destination}
                  onChange={(e) => updateField('destination', e.target.value)}
                  className={inputClass('destination')}
                />
                {errors.destination && <p className="text-red-400 text-xs mt-1">{errors.destination}</p>}
              </div>
            </div>

            {/* Date, Time, Passengers */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className={labelClass}>
                  <Calendar className="w-3 h-3 inline mr-1" /> Date
                </label>
                <input
                  type="date"
                  value={formData.booking_date}
                  onChange={(e) => updateField('booking_date', e.target.value)}
                  className={inputClass('booking_date')}
                  min={new Date().toISOString().split('T')[0]}
                />
                {errors.booking_date && <p className="text-red-400 text-xs mt-1">{errors.booking_date}</p>}
              </div>
              <div>
                <label className={labelClass}>
                  <Clock className="w-3 h-3 inline mr-1" /> Time
                </label>
                <input
                  type="time"
                  value={formData.booking_time}
                  onChange={(e) => updateField('booking_time', e.target.value)}
                  className={inputClass('booking_time')}
                />
                {errors.booking_time && <p className="text-red-400 text-xs mt-1">{errors.booking_time}</p>}
              </div>
              <div>
                <label className={labelClass}>
                  <Users className="w-3 h-3 inline mr-1" /> Passengers
                </label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={formData.passengers}
                  onChange={(e) => updateField('passengers', Math.max(1, parseInt(e.target.value) || 1))}
                  className={inputClass('passengers')}
                />
                {errors.passengers && <p className="text-red-400 text-xs mt-1">{errors.passengers}</p>}
              </div>
            </div>

            {/* Status Messages */}
            {status === 'success' && (
              <div className="flex items-center gap-3 bg-green-500/10 border border-green-500/30 rounded-xl px-5 py-4">
                <CheckCircle className="w-5 h-5 text-green-400 shrink-0" />
                <p className="text-green-300 text-sm">{serverMessage}</p>
              </div>
            )}

            {status === 'error' && (
              <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/30 rounded-xl px-5 py-4">
                <XCircle className="w-5 h-5 text-red-400 shrink-0" />
                <p className="text-red-300 text-sm">{serverMessage}</p>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={status === 'loading'}
              className="w-full liquid-glass rounded-full px-8 py-4 text-white text-sm font-medium hover:bg-white/5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              {status === 'loading' ? (
                <>
                  <Loader className="w-4 h-4 animate-spin" />
                  Booking...
                </>
              ) : (
                <>
                  <Car className="w-4 h-4" />
                  Book Your Ride
                </>
              )}
            </button>

            <p className="text-white/20 text-xs text-center">
              By booking, you agree to our terms of service. We'll confirm your ride via phone.
            </p>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default BookingForm;